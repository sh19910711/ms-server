#include <app.h>

void setup() {
    syntax_error!!!
}
